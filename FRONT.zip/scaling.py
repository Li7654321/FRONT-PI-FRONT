#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Purpose: 物理量的归一化与反归一化
created by Gemini @2026/3/9
modified by jl @2026/4/17
"""

import numpy as np

# 全局物理参数配置 (必须与处理脚本保持一致)
# ==============================================================================
MAX_SLIP = 20.0   # 米 (m)
MAX_RISE = 35.0   # 秒 (s)
MAX_RUPT = 260.0  # 秒 (s)
MIN_MAG = 6.0
MAX_MAG = 9.0


def d_scale(y):
    """归一化: [0, 20.0] -> [0, 1.0]"""
    return y / MAX_SLIP

def d_scaleback(y):
    """反归一化: [0, 1.0] -> [0, 20.0] m"""
    return y * MAX_SLIP

def r_scale(x, inverse=False):
    if inverse:
        return x * MAX_RISE
    return x / MAX_RISE

def t_scale(x, max_val=MAX_RUPT, inverse=False):
    if inverse:
        return x * max_val
    return x / max_val

def m_scale(mw):
    """将震级归一化到 [0, 1] 区间"""
    return (mw - MIN_MAG) / (MAX_MAG - MIN_MAG)

def m_descale(mw_norm):
    """将 [0, 1] 区间的网络输出还原为真实震级"""
    return mw_norm * (MAX_MAG - MIN_MAG) + MIN_MAG