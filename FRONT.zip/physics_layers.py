#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Purpose: 物理信息神经网络 - 波形正演合成层
created by Gemini @2026/3/6
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

# ==============================================================================
# JIT 算子融合：计算震源时间函数 (STF) 的频域包络与相位延迟
# ==============================================================================
@torch.jit.script
def compute_stf_complex(omega: torch.Tensor, half_rise: torch.Tensor, rupt_time: torch.Tensor) -> torch.Tensor:
    arg = omega * half_rise

    # ---------------------------------------------------------
    safe_arg = torch.where(arg == 0.0, torch.ones_like(arg), arg)
    
    # 使用 safe_arg 进行除法计算，前向和反向都绝对不会出现 NaN
    sinc_term = torch.where(arg == 0.0, torch.ones_like(arg), torch.sin(safe_arg) / safe_arg)
    sinc_sq = sinc_term ** 2

    # phase_delay = 破裂传播延迟 + STF半宽延迟
    phase_delay = half_rise + rupt_time
    phase_angle = -1.0 * omega * phase_delay

    # ---------------------------------------------------------
    real_part = sinc_sq * torch.cos(phase_angle)
    imag_part = sinc_sq * torch.sin(phase_angle)
    
    return torch.complex(real_part, imag_part)


# ==============================================================================
# 核心物理波形合成层
# ==============================================================================
class WaveformSynthesizer(nn.Module):
    def __init__(self, gf_shape, dt, max_vals, gf_tensor=None):
        super(WaveformSynthesizer, self).__init__()
        self.gf_shape = gf_shape
        self.dt = dt
        self.scales = max_vals

        self.nt = gf_shape[3]  # 原始时间步长: 512

        # 将 FFT 长度翻倍 (1024)，防止循环卷积的尾部混叠到前端
        self.pad_nt = self.nt * 2
        self.total_bins = self.pad_nt // 2 + 1

        nyquist = 1.0 / (2.0 * dt)
        cutoff_freq = 0.5  # 截断频率

        # 使用翻倍后的长度计算有效频点
        self.valid_bins = int((cutoff_freq / nyquist) * (self.pad_nt // 2)) + 1

        if gf_tensor is not None:
            if not isinstance(gf_tensor, torch.Tensor):
                gf_tensor = torch.tensor(gf_tensor, dtype=torch.float32)

            # 在格林函数时域末尾补零 (补512个0)，使其长度变为 1024
            gf_padded = F.pad(gf_tensor, (0, self.pad_nt - self.nt))

            gf_spec_val = torch.fft.rfft(gf_padded, dim=-1)
            gf_spec_truncated = gf_spec_val[..., :self.valid_bins]
            self.register_buffer('gf_spec_trunc', gf_spec_truncated)
        else:
            self.gf_spec_trunc = None

    def forward(self, src, rup):
        batch_size = src.size(0)

        # 1. 恢复物理量纲
        ss_slip = src[:, 0:1, :] * self.scales['slip']
        ds_slip = src[:, 1:2, :] * self.scales['slip']

        # 强制 Rise Time 至少有 0.01 秒，防止物理崩溃
        rise_time = src[:, 2:3, :] * self.scales['rise'] + 1e-2
        rupt_time = rup * self.scales['rupt']

        # 2. 生成有效频段的角频率 omega
        freqs = torch.fft.rfftfreq(self.pad_nt, d=self.dt, device=src.device)[:self.valid_bins]
        omega = 2.0 * torch.pi * freqs
        omega_grid = omega.view(1, 1, 1, -1)

        # 3. 调整张量形状以供 JIT 算子运算
        half_rise_exp = (rise_time * 0.5).permute(0, 2, 1).unsqueeze(-1)
        rupt_time_exp = rupt_time.permute(0, 2, 1).unsqueeze(-1)

        # 4. 计算带有延迟的震源时间函数复数包络
        stf_spec_complex = compute_stf_complex(omega_grid, half_rise_exp, rupt_time_exp)

        # 5. 滑移量转为复数张量
        ss_c = ss_slip.permute(0, 2, 1).unsqueeze(-1).to(torch.complex64)
        ds_c = ds_slip.permute(0, 2, 1).unsqueeze(-1).to(torch.complex64)

        # 6. 获取格林函数频谱并扩展 Batch 维度 (已经是 1024 长度的频谱)
        gf_ss = self.gf_spec_trunc[:, 0, :, :].unsqueeze(0)
        gf_ds = self.gf_spec_trunc[:, 1, :, :].unsqueeze(0)

        # 7. 频域相乘与空间坍缩
        base_resp = ss_c * gf_ss + ds_c * gf_ds
        full_resp_sub = base_resp * stf_spec_complex
        total_spec_trunc = torch.sum(full_resp_sub, dim=1)

        # 8. 频域补零缝合
        pad_size = self.total_bins - self.valid_bins
        total_spec = F.pad(total_spec_trunc, (0, pad_size))

        # 9. 逆傅里叶变换转回时域
        waveforms_padded = torch.fft.irfft(total_spec, n=self.pad_nt, dim=-1)
        waveforms = waveforms_padded[..., :self.nt]

        # 10. 重塑形状 (依然输出 512 给模型)
        waveforms = waveforms.permute(0, 2, 1)
        n_sta = self.gf_shape[2] // 3
        waveforms = waveforms.view(batch_size, self.nt, n_sta, 3)

        return waveforms